This repo will be used by team-15 for JP Morgan Code For Good NYC 2015
